# -*- coding: utf-8 -*-
"""
Created on Thu Dec 10 12:35:26 2020

@author: Vinay
"""
import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

df=pd.read_csv("drugeffects.csv",index_col=0)
df['condition'] = df['condition'].fillna(df['condition'].mode()[0])

mappings=list()
cols=['urlDrugName','effectiveness','condition','sideEffects']
labelencoder=LabelEncoder()
for x in cols:
    df[x]=labelencoder.fit_transform(df[x])
    mappings_dict={index:label for index, label in enumerate(labelencoder.classes_)}
    mappings.append(mappings_dict)
print(mappings)

x=df.drop('sideEffects',axis=1)
y=df['sideEffects']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.3,random_state=42)
#Since the data set is too small we are taking the whole data in train model
from sklearn.ensemble import GradientBoostingClassifier
classifier=GradientBoostingClassifier(n_estimators=58,random_state=123,min_samples_split=0.07)
#fitting the model
m=classifier.fit(x_train,y_train)
#saving the model to disk
pickle.dump(classifier,open('model.pkl','wb'))

example_dict={1: 'Mild Side Effects', 2: 'Moderate Side Effects', 3: 'No Side Effects', 4: 'Severe Side Effects'}

pickle_out=open("dict_pickle.pkl","wb")
pickle.dump(example_dict,pickle_out)
pickle_out.close()
