# -*- coding: utf-8 -*-
"""
Created on Thu Dec 10 12:50:22 2020

@author: Vinay
"""

from flask import Flask,render_template,request
import pickle
import numpy as np
import os

PEOPLE_FOLDER=os.path.join('static')


app=Flask(__name__)
model=pickle.load(open('model.pkl','rb'))
app.config['UPLOAD_FOLDER']=PEOPLE_FOLDER


@app.route('/')
def home():
    return render_template('home.html')

#taking the input values from the home.html
@app.route('/predict',methods=['POST'])


def predict():
        urlDrugName	=int(request.values['urlDrugName'])
        rating=int(request.values['rating'])
        effectiveness=int(request.values['effectiveness'])
        condition=int(request.values['condition'])
#predicting input values using model     
        s=np.array([urlDrugName	,rating,effectiveness,condition])
        s=np.reshape(s,(-1,4))
        output=model.predict(s)
        output=output.item()

        #converting to meaningful result and printing output
        pickle_in=open("dict_pickle.pkl","rb")
        example_dict=pickle.load(pickle_in)
        output=example_dict[output]
        print(output)
        return render_template ('result.html',prediction_text="This Drug may cause {}.  Thank you!!!".format(output))
def results():
    oip = os.path.join(app.config['UPLOAD_FOLDER'], 'drug.jpeg')
    return render_template('result.html', user_image=oip)


if __name__=='__main__':
  app.run(port=8000)